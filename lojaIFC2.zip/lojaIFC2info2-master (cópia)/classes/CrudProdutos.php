<?php

/**
 * Created by PhpStorm.
 * User: aluno
 * Date: 17/11/17
 * Time: 10:46
 */
require_once "Conexao.php";
class CrudProdutos
{
    private $conexao;
    public function __construct()
    {
        $this->conexao = Conexao::getConexao();
    }

    public function cadastrar(){
        $sql = "INSERT INTO tb_produtos (nome, preco, categoria, estoque) VALUES ('$this->nome', $this->preco, '$this->categoria', $this->estoque)";


        $this->conexao->exec($sql);
    }
    public function buscar(int $codigo){
        $c = $this->conexao->query("SELECT * FROM tb_produtos WHERE codigo = $codigo");
        $produto = $c->fetch(PDO::FETCH_ASSOC);

        return $produto;
    }

    public function getProdutos(){
        $sql = "SELECT * FROM tb_produtos";


        $consulta = $this->conexao->query($sql);

        $listaProdutos = $consulta->fetchAll(PDO::FETCH_ASSOC);

        return $listaProdutos;

    }
}