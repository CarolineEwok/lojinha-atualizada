<?php
/**
 * Created by PhpStorm.
 * User: JEFFERSON
 * Date: 10/11/2017
 * Time: 10:52
 */

class Conexao {

    const SERVIDOR  = "localhost";
    const NOMEBANCO = "bd_loja_2info3";
    const USUARIO   = "root";
    const SENHA     = "root";
    private static $conexao = null;

    public static function getConexao(){

        if (self::$conexao == null){

        $conexao = new PDO("mysql:host=".self::SERVIDOR.";dbname=".self::NOMEBANCO , self::USUARIO, self::SENHA);

        //mostrar os erros ocorridos laa no banco
        $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        self::$conexao = $conexao;

        }
        return self::$conexao;
    }
}
//teste conexao
