<?php
    require_once "classes/CruProdutos";
    $crud = new CrudProdutos();
    $produto = $crud->buscar(1);
    print_r($produto);
?>
<h2>Pagina de produto</h2>